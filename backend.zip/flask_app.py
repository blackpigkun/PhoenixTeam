import os
import re

import urllib as ur
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings('ignore')
from pandas.io.json import json_normalize
import json
import time
import datetime

# A very simple Flask Hello World app for you to get started with...
import requests
from flask import Flask, request, jsonify, redirect
#from sklearn.linear_model import LogisticRegression

import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

api_key = "4549551277e8716836a5ae1b65078d2f"
secret_key = "100705b4211b5c7b803d330ff783c5fa"

def re_format_time(tim):
  tim=pd.to_datetime(tim)
  tim=datetime.datetime.fromtimestamp(tim.timestamp()).replace(tzinfo=datetime.timezone.utc).isoformat()
  return pd.to_datetime(tim)

def setLabel(_org, _variants, _label):
  _org["variants"] = _variants["variants"]
  _org["label"]=[0]*len(_org)
  _org.loc[np.in1d(_org["id"],_label), ["label"]]=1
  return _org

def dataFrame2Json(_df, _parent = 'products'):
  _returnData = ""
  temp = str(int(round(time.time() * 1000)))
  _filename = "data%s.json" % temp
  _df.to_json(_filename,orient="records", force_ascii=False)
  with open(_filename, 'w', encoding='utf-8') as _file:
    _df.to_json(_file, orient="records", force_ascii=False)

  with open(_filename) as _f:
    _returnData = json.load(_f)
  if os.path.exists(_filename):
    os.remove(_filename)
  return {_parent: _returnData}

def dataFrame2JsonNoParent(_df):
  _returnData = ""
  temp = str(int(round(time.time() * 1000)))
  _filename = "data%s.json" % temp
  _df.to_json(_filename,orient="records", force_ascii=False)
  with open(_filename, 'w', encoding='utf-8') as _file:
    _df.to_json(_file, orient="records", force_ascii=False)

  with open(_filename) as _f:
    _returnData = json.load(_f)
  if os.path.exists(_filename):
    os.remove(_filename)
  return _returnData

def getRules(_shop):
    cred = credentials.Certificate('./mysite/phoenix-9cc3b-firebase-adminsdk-stla8-cfe6ee6af4.json')
    app_fb = firebase_admin.initialize_app(cred, {'databaseURL': 'https://phoenix-9cc3b.firebaseio.com'})
    ref = db.reference('/shopOwners')
    _db = ref.get()
    result = {}
    for shop in _db:
      if (shop["shopName"] == (str)(_shop)):
          result = shop
          break;

    firebase_admin.delete_app(app_fb)
    return result

def storeProducts(_shop,_products):
    cred = credentials.Certificate('./mysite/phoenix-9cc3b-firebase-adminsdk-stla8-cfe6ee6af4.json')
    app_fb = firebase_admin.initialize_app(cred, {'databaseURL': 'https://phoenix-9cc3b.firebaseio.com'})
    ref = db.reference('/shopOwners')
    _db = ref.get()
    for key, shop in enumerate(_db):
      if (shop["shopName"] == (str)(_shop)):
        ref.child(f"{key}").update(_products)
        break
    firebase_admin.delete_app(app_fb)
    return True

def setRule(_shop):
    cred = credentials.Certificate('./mysite/phoenix-9cc3b-firebase-adminsdk-stla8-cfe6ee6af4.json')
    app_fb = firebase_admin.initialize_app(cred, {'databaseURL': 'https://phoenix-9cc3b.firebaseio.com'})
    ref = db.reference('/shopOwners')
    _db = ref.get()
    _respond = ""
    for key, shop in enumerate(_db):
        if (shop["shopName"] == (str)(_shop)):
            if ("settingRules" in shop.keys()):
                _org = pd.DataFrame.from_records(shop['products'])
                _variants = json_normalize(shop['products'], 'variants')
                _variants = _variants[(_variants["discount"] == 0) & (_variants["duration"] == 0)]
                if (len(_variants) > 0):
                    _rules = pd.DataFrame(columns=["date", "discount", "duration"])
                    for _rule in shop["settingRules"]:
                        _rules=_rules.append(pd.Series([_rule["date"], _rule["discount"], _rule["duration"]], index=_rules.columns ), ignore_index=True)

                    _today=datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
                    _today = pd.to_datetime(_today)

                    _tmp_time = _variants["last_order"].apply(lambda x: re_format_time(x))
                    _variants["last_sell"] = (_today-_tmp_time).dt.days
                    _temp=_rules.sort_values(["discount"],ascending=False)
                    _temp["date_apply"] = _today
                    for i, _variant in _variants.iterrows():
                        for index, rule in _temp.iterrows():
                            if ((int)(_variant["last_sell"])>=(int)(rule["date"])):
                                _variants.loc[_variants["id"]==_variant["id"],["discount", "duration", "date_apply"]] = rule[["discount", "duration", "date_apply"]].values
                                break

                    _return_variants = _variants.groupby('product_id').apply(lambda x: dataFrame2JsonNoParent(x))
                    _return_df = _return_variants.rename_axis('product_id').reset_index(name='variants')
                    _label=_variants[_variants["discount"].astype('int')>0]["product_id"].unique()
                    _return_data = setLabel(_org,_return_df,_label)
                    _respond = dataFrame2Json(_return_data,_parent="products")

                    ref.child(f"{key}").update(_respond)
                    break
    firebase_admin.delete_app(app_fb)
    return _respond
def getWarnProducts(_shop):
    cred = credentials.Certificate('./mysite/phoenix-9cc3b-firebase-adminsdk-stla8-cfe6ee6af4.json')
    app_fb = firebase_admin.initialize_app(cred, {'databaseURL': 'https://phoenix-9cc3b.firebaseio.com'})
    ref = db.reference('/shopOwners')
    _db = ref.get()
    _warn = pd.DataFrame()
    for key, shop in enumerate(_db):
        if (shop["shopName"] == (str)(_shop)):
            _org = pd.DataFrame.from_records(shop["products"])
            _warn = _org[_org["label"] == 1]
            break
    firebase_admin.delete_app(app_fb)
    return _warn
def saveData(_shop,_products,_orders):
    _respond = "Oh no..."
    cred = credentials.Certificate('./mysite/phoenix-9cc3b-firebase-adminsdk-stla8-cfe6ee6af4.json')
    app_fb = firebase_admin.initialize_app(cred, {'databaseURL': 'https://phoenix-9cc3b.firebaseio.com'})
    ref = db.reference('/shopOwners')
    _db = ref.get()

    for key, shop in enumerate(_db):
        if (shop["shopName"] == (str)(_shop)):
            # Code here
            _orgProduct = pd.DataFrame.from_records(_products)
            _variants = json_normalize(_products, 'variants')

            _today=datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
            _default=datetime.datetime(1980, 1, 1).replace(tzinfo=datetime.timezone.utc).isoformat()
            _order_df=json_normalize(_orders, 'line_items', ['updated_at'])

            _today = pd.to_datetime(_today)
            _default = pd.to_datetime(_default)
            _order_df["updated_at"] = pd.to_datetime(_order_df.updated_at)
            _last_order = _order_df[["variant_id", "updated_at"]].groupby(by=['variant_id']).max().rename_axis('variant_id').reset_index()
            _variants["last_order"]=_default
            _exist_id=_variants[np.in1d(_variants["id"],_last_order["variant_id"])]["id"]
            _variants.loc[np.in1d(_variants["id"],_last_order["variant_id"]), ["last_order"]]=_last_order[np.in1d(_last_order["variant_id"],_exist_id)]["updated_at"].values
            _variants["last_sell"] = (_today-_variants["last_order"]).dt.days
            _variants["discount"] = 0
            _variants["duration"] = 0
            _variants["date_apply"] = _today
            _variants["org_price"] = _variants["price"]
            _variants["sold"] = 0
            _orgProduct["label"] = 0
            _return_variants = _variants.groupby('product_id').apply(lambda x: dataFrame2JsonNoParent(x))
            _return_df = _return_variants.rename_axis('product_id').reset_index(name='variants')
            _orgProduct["variants"] = _return_df["variants"]
            _respond = dataFrame2Json(_orgProduct,_parent="products")
            ref.child(f"{key}").update(_respond)
            break;
    firebase_admin.delete_app(app_fb)
    return _respond



app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False

@app.route('/')
def hello_world():
    return 'Hello from Flask!9'

@app.route('/path')
def path():
    return os.getcwd()

@app.route('/install', methods=['POST'])
def install():
    data = request.json
    cred = credentials.Certificate('./mysite/phoenix-9cc3b-firebase-adminsdk-stla8-cfe6ee6af4.json')
    app_fb = firebase_admin.initialize_app(cred, {'databaseURL': 'https://phoenix-9cc3b.firebaseio.com'})
    ref = db.reference('/shopOwners')
    _db = ref.get()
    shop_key = len(_db)
    ref.update({shop_key : data})

    firebase_admin.delete_app(app_fb)
    return "OK"

@app.route('/updatePrice')
def updatePrice():
    shop = "phoenix05.myharavan.com"
    token = "JJRpmFQG9ufdlIrn5kteOOF4xpJCklf0lnryikbznvbgt-MK6WDZWmr_avXNSSRh0kXbEsGdlHhgu8wj_10uyHH6oP_Qtz9BwTxLDLzW_rltCVvtz7t273nWCWEDVaq3Jd3SQyf5LgdW4m5mpEchgbY1m5rkqufCduiOVb8m-q8xGflZ6LrUKogXxA6QtCJnEedP0k-jiY3Kg3hQQOZFV_UZ3ci6mENeUSQkQgD7qKtpcRkI4JBk2SY3mXP0_MPEATOTQ4fLurLljP9qPXVgkGReV6m2TIIwFfHpQ_s5R0Y08pm2f98uzq8B32EJ1tL2Sl-9OPqFZamzZMKOo5yw-oKNbo7gZ13wqkq72spajGnJRHLsh26jLLkE1xNPlFm4Mi765HH8IP4uoZQ8yTh2nDVnsuiWMWe6Ae26MjTZQuAsNblrUCma5L2eHCu7l00m6zjajqfLtc75S86nivsqF-AyXOoH0ZU_X42REh8tHozaZyju143FNSz6JcK4dhNj7Ah9tA"
    url = f"https://{shop}/admin/variants/1043492527.json"
    head = {'Authorization': 'Bearer ' + token}

    r = requests.put(url,headers=head,data={"variant": {"id": 1043492530, "price": "3333"}},verify=False)
    return r.status_code

@app.route('/firebase')
def firebase():
    return jsonify(getRules("phoenix05.myharavan.com"))

@app.route("/product", methods=['POST'])
def product():
    '''// POST to https://SHOP_NAME.myharavan.com/admin/oauth/access_token'''
    # # shop = request.values["shop"]
    # # timestamp = request.values["timestamp"]
    # # signature = request.values["signature"]
    # # code = request.values["code"]
    # auth_token='9ojHJRuqNwtaS48kX8H5XC3jTndmthOKPSF_3iUMnC5cWPKs0N6U8sJvH7ndzkh0Nsr_nAi3-GwNk9Txdcx6SJF2Fg2dNP2-UVHvNQC4qe9XEjWNMZz1R4JpqNOxOHeKQ62UtvNTAyw_fmIeC5_nUU5J1TT9mTZ38t4P9TF2iZ8jQvDP4ouaqfBPb4Od31BZ6uffKxbiniiKjQCcoUbj0-ATcjWVQaiz4OPk-1IaDkepkx6wbl2WMUYyWO3Evg_XKjNcPQpoa0Nu62rjAlieAwsHULflXx_oefshE4wqcEBQ75AvuyVzDviQ6pjeibov9HuJUNTEMTZ-TtQ47cmwURQ7hbzHob0eLbwNEvOzfqPKl9TZfDEnFGIZImsDFC1y4TvNr7hSJU3rNZ7Mod_tyxWUITzf5y5TSFeEM9R7bERnoDCknfevo_Ukuq3FPxLWLW1t61dOr2EkUttk2fX_dovvy_M0-_In03dNH9DLXobbIOlSyMoAc6y07RMNh-6nKoKiMA'
    # head = {'Authorization': 'Bearer ' + auth_token}
    # url_product = "http://teamphoenix05.myharavan.com/admin/products.json"
    # r = requests.get(url_product, headers=head)
    # return r.status_code
    # Main json
    data = request.json
    shop = "phoenix05.myharavan.com"
# Origin data
    org = pd.DataFrame.from_records(data['products'])
# Variants data
    product_df = json_normalize(data['products'], 'variants')
# Điều kiện lọc là sp phải có quản lý tồn kho
    product_df = product_df[(product_df["inventory_management"].isna() == False) & (product_df["inventory_quantity"]>0)] # Bảng biến thể

    product_ids = product_df["product_id"].unique() # List product_ids

    # org = org[np.in1d(org["id"],product_ids)] # Lọc ra sản phẩm có trong product_ids

    return_data=dataFrame2Json(org,_parent="products") # Chuyển về json
    storeProducts(shop,return_data)
    return jsonify(return_data)

@app.route('/warned')
def warned():
    shop = "phoenix05.myharavan.com"
    data = getWarnProducts(shop)
    return_data=dataFrame2Json(data,_parent="products") # Chuyển về json
    return jsonify(return_data)

@app.route('/setRules')
def setRules():
    shop = "phoenix05.myharavan.com"
    return_data=setRule(shop) # Chuyển về json
    return jsonify(return_data)

@app.route('/save', methods=['POST'])
def save():
    shop = "phoenix05.myharavan.com"
    data = request.json
    return_data=saveData(shop,data["products"],data["orders"]) # Chuyển về json
    return jsonify(return_data)

@app.route('/schedule')
def schedule():
    shop = "phoenix05.myharavan.com"
    cred = credentials.Certificate('./mysite/phoenix-9cc3b-firebase-adminsdk-stla8-cfe6ee6af4.json')
    app_fb = firebase_admin.initialize_app(cred, {'databaseURL': 'https://phoenix-9cc3b.firebaseio.com'})
    ref = db.reference('/shopOwners')
    _db = ref.get()
    for key, shop in enumerate(_db):
        ref_product = ref.child(f"{key}/products")
        products = ref_product.get()
        for p_key, p_val in enumerate(products):
            label = 0
            ref_variant = ref_product.child(f"{p_key}/variants")
            variants = ref_variant.get()
            for v_key, v_val in enumerate(variants):
                if ((int)(v_val["discount"])==0 and (int)(v_val["duration"])==0):
                    continue
                else:
                    ref_final = ref_variant.child((str)(v_key))
                    v_val["duration"] = (int)(v_val["duration"])-1
                    if (v_val["duration"]<0):
                        v_val["duration"] = 0
                        v_val["discount"] = 0
                    else:
                        label = 1
                    ref_final.update(v_val)
            spe_product = ref_product.child((str)(p_key)).get()
            spe_product["label"] = label
            ref_product.child((str)(p_key)).update(spe_product)

    firebase_admin.delete_app(app_fb)
    return "OK"

@app.route('/listDiscount', methods=['POST'])
def listDiscount():
    shop = "phoenix05.myharavan.com"
    cred = credentials.Certificate('./mysite/phoenix-9cc3b-firebase-adminsdk-stla8-cfe6ee6af4.json')
    app_fb = firebase_admin.initialize_app(cred, {'databaseURL': 'https://phoenix-9cc3b.firebaseio.com'})
    ref = db.reference('/shopOwners')
    _db = ref.get()
    _res = []
    for key, shop in enumerate(_db):
        ref1 = ref.child(f"{key}").child("products")
        list_products = ref1.get()
        for p_key, p_val in enumerate(list_products):
            if (p_val["label"] == 1):
                p_label = 0
                ref2 = ref1.child(f"{p_key}").child("variants")
                list_variants = ref2.get()
                for v_key, v_val in enumerate(list_variants):
                    if (v_val["discount"] > 0):
                        if (v_val["duration"] > 0):
                            v_val["price"] = (int)(v_val["org_price"]*(1-(float)(v_val["discount"])/100))
                            v_val["duration"] = v_val["duration"] - 1
                            p_label = 1
                        else:
                            v_val["price"] = v_val["org_price"]
                            v_val["discount"] = 0
                            v_val["duration"] = 0
                        ref2.child(f"{v_key}").update(v_val)
                p_val["label"] = p_label
                ref1.child(f"{p_key}").update(p_val)
        shop = ref.child(f"{key}").get()
        _res.append(dataFrame2JsonNoParent(json_normalize(shop, ['products', 'variants'], ['isAutomatic', 'shopName'])))
    firebase_admin.delete_app(app_fb)
    return jsonify({"shop" : _res})